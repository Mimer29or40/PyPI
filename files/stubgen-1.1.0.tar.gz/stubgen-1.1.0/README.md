# pythonnet-stubs

Generate stubs for .NET libraries
